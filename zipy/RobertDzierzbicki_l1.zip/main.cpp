#include <SFML/Graphics.hpp>
#include <string>

int main()
{
    sf::RenderWindow window(sf::VideoMode({ 1280, 720 }), "Zadanie 1");

    sf::CircleShape circle(50.f);
    sf::RectangleShape rect(sf::Vector2f(50, 50));

    const sf::Texture rectTexture("../src/textures/texture1.png");
    const sf::Texture circleTexture("../src/textures/texture2.png");

    circle.setPosition(sf::Vector2f(10, 10));
    rect.setPosition(sf::Vector2f(640, 10));

    circle.setTexture(&circleTexture);
    rect.setTexture(&rectTexture);

    sf::Clock clock;
    sf::Vector2f circleSpeed = sf::Vector2f(50.f, 50.f);
    sf::Vector2f rectSpeed = sf::Vector2f(0.f, 25.f);

    while (window.isOpen())
    {
        while (const std::optional event = window.pollEvent()) // obsluga zdarzen
        {
            if (event->is<sf::Event::Closed>())
                window.close();
        }

        float delta = clock.restart().asSeconds();

        circle.move(circleSpeed * delta);
        rect.move(rectSpeed * delta);

        window.clear(sf::Color(111, 194, 118));
        window.draw(circle);
        window.draw(rect);
        window.display();
    }
}