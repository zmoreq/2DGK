#include "Game.h"

Game::Game(int windowWidth, int windowHeight) {
	this->windowWidth = windowWidth;
	this->windowHeight = windowHeight;
}

Game::~Game() {
}